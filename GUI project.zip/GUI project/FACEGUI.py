#!/usr/bin/env python
# coding: utf-8

# In[2]:


from tkinter import*
from PIL import ImageTk, Image
import cv2,os

import numpy as np

def train_classifer(data_dir):
    # Read all the images in custom data-set
    path = [os.path.join(data_dir, f) for f in os.listdir(data_dir)]
    faces = []
    ids = []

    # Store images in a numpy format and ids of the user on the same index in imageNp and id lists
    for image in path:
        img = Image.open(image).convert('L')
        imageNp = np.array(img, 'uint8')
        idd = int(os.path.split(image)[1].split(".")[1])

        faces.append(imageNp)
        ids.append(idd)

    ids = np.array(ids)
        # Train and save classifier
    
    clf = cv2.face.LBPHFaceRecognizer_create()
    clf.train(faces,ids)

    clf.write("classifier.xml")

    


faceCascade=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
def dataset(img,userid,imageID):
    if imageID<50:
        cv2.imwrite("pics/user."+str(userid)+"."+str(imageID)+".jpg",img)
        
def detect(img,faceCascade,imgID,userid):
    
    gray_img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    
    features=faceCascade.detectMultiScale(gray_img,1.2,9)
    coords=[]
    for (x,y,w,h) in features:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
    
        coords=[x,y,w,h]
    if len(coords)==4:
        rimg=img[coords[1]:coords[1]+coords[3],coords[0]:coords[0]+coords[2]]

        dataset(rimg,userid,imgID)

    return img

def draw(img,classifier,scaleFactor,minNeighbors,color ,clf,names):
    gra_img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    features=classifier.detectMultiScale(gra_img,scaleFactor,minNeighbors)
    coords=[]
    for (x,y,w,h) in features:
        cv2.rectangle(img,(x,y),(x+w,y+h),color,2)
        idd,_=clf.predict(gra_img[y:y+w,x:x+h])
        
        for i in range(len(names)):
            if i == idd:
                cv2.putText(img,names[idd],(x,y-4),cv2.FONT_HERSHEY_SIMPLEX,0.8,color,1,cv2.LINE_AA)   
                
        coords=[x,y,w,h]
    return coords   
def recognize(img,clf,faceCascade,names):
    coords= draw(img,faceCascade,1.2,9,(255,255,255),clf,names)
    
    return img


win=Tk()
win.title("app")
win.geometry("900x600")

videoFrame=Frame(win).grid()

root=Frame(win).grid()
lmain = Label(videoFrame)
lmain.place(x=0,y=100)
cap = cv2.VideoCapture(0)
imgID=0
file1=open("userID.txt","r")
Uid=file1.read()
file1.close()
# function for video streaming


def video_recog():
    clf= cv2.face.LBPHFaceRecognizer_create()
    clf.read("classifier.xml")

    _, cv2image = cap.read()
    
    names=[]
    file = open("Names.txt","r")
    for n in file.readlines():
        names.append(n)
    names="\n".join(names).split()
    file.close()
    
    cv2image= recognize(cv2image,clf,faceCascade,names)
    cv2image = cv2.cvtColor(cv2image, cv2.COLOR_BGR2RGBA)
    img = Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    
    lmain.configure(image=imgtk)
    lmain.after(1, video_recog) 
def video_stream():
    global imgID
    imgID+=1
    
    
    _, frame = cap.read()
    
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    cv2image= detect(cv2image,faceCascade,imgID,Uid)
   
    img = Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    
    lmain.configure(image=imgtk)
    lmain.after(1, video_stream) 
Uid=int(Uid)+1
file2=open("userID.txt","w")
file2.write(str(Uid))
file2.close()

name=StringVar()
def add():
    global name 
    name = name.get()
    
    file=open("Names.txt","a")
    file.writelines(name+"\n")
    file.close()
    
    video_stream()
    train_classifer("pics")
def recog():
    names=[]
    file = open("Names.txt","r")
    for n in file.readlines():
        names.append(n)
    names="\n".join(names).split()
    file.close()
    
    video_recog()
namelabel_2=Label(win,text="Face Recognition",font=('Palatino',50))
namelabel_2.place(x=50,y=0)

namelabel_2=Label(root,text="NAME :",font='times 12 bold italic')
namelabel_2.place(x=650,y=230)

name=Entry(root,textvariable=name)
name.place(x=730,y=230)

train_button = Button(root, text="Add",font=('times 12 bold italic',10),command=add)
train_button.place(x=800,y=500)

recog_button = Button(root, text="Recognition",font=('times 12 bold italic',10),command=recog)
recog_button.place(x=700,y=500)



quit = Button(win, bg="red", text="Quit", command=win.destroy)


win.mainloop()

